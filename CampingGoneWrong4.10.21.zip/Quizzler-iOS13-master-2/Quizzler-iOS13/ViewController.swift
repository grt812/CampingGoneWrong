//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//  pingu

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scenerioLabel: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var optionOne: UIButton!
    @IBOutlet weak var optionTwo: UIButton!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    let pathways = [
        Scenerio(id: 1, text: "During the night, your irresponsible parents allow you to go camping by yourself. You say goodbye to your parents who are happy to see you leave and drive hundreds of miles away in a forest. You travel into the depths of the woods, you find a nice place to rest and set up a tent. The sun starts to set and you hear your stomach grumble.", optionOne: "Eat the food you brought with you", optionTwo: "Go hunting", idOne: 2, idTwo: 3, image: #imageLiteral(resourceName: "pasted image 0")),
        Scenerio(id: 2, text: "After you eat your Oreos, you have a lot of crumbs and ants.", optionOne: "Go to the river to wash the ants.", optionTwo: "Ignore the ants", idOne: 4, idTwo: 5, image:#imageLiteral(resourceName: "pasted image 0")),
        Scenerio(id: 4, text: "As you wash, you accidentally fall in the river(so clumsy).", optionOne: "Swim", optionTwo: "Yell", idOne: 6, idTwo: 7, image:#imageLiteral(resourceName: "pasted image 0-4")),
        Scenerio(id: 6, text: "You manage to swim to shore but not before the river carries you a long way from your campsite. Your phone didn’t work because water got stuck in it.", optionOne: "Yell for help", optionTwo: "Cry", idOne: 8, idTwo: 9, image:#imageLiteral(resourceName: "pasted image 0-4")),
        Scenerio(id: 8, text: "You yell and attract bears. You get eaten. Life Grade: D", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "Bear")),
        Scenerio(id: 9, text: "You cry and attract wolves and die being ripped into pieces. Life Grade: D", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "Wolves")),
        Scenerio(id: 7, text: "You yell and attract bears. You get eaten. Life Grade: D", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "Bear")),
        Scenerio(id: 5, text: "The ants bite you and you get a rash.", optionOne: "Ignore", optionTwo: "Apply Medicine", idOne: 10, idTwo: 11, image:#imageLiteral(resourceName: "pasted image 0")),
        Scenerio(id: 10, text: "You go to sleep but the infection goes through your whole body, you die. Life Grade: D", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "pasted image 0")),
        Scenerio(id: 11, text: "You get better after you apply the medicine, but one of the side effects of the medicine is that it makes you smell like food. A giant bear comes over and thinks that you are food. What do you do?", optionOne: "Fight it with a stick", optionTwo: "Run", idOne: 12, idTwo: 13, image:#imageLiteral(resourceName: "Bear")),
        Scenerio(id: 12, text: "You fight the bear with the stick and it dies. You roast the meat over the fire. You brag to all your friends back home about your accomplishment. Life Grade: A", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "FireInCave")),
        Scenerio(id: 13, text: "You tried to outrun the bear. You outran it but the bear starts to destroy your car and you get stuck in the forest for 2 weeks. You're eventually rescued. Life Grade: B", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "NS_mixed_forest")),
        Scenerio(id: 3, text: "You walk through the forest very quietly as you try to look for any possible animals. Something scurries behind you: IT’S BIGFOOT.", optionOne: "Hide", optionTwo: "Shoot", idOne: 14, idTwo: 15, image:#imageLiteral(resourceName: "Bigfoot")),
        Scenerio(id: 14, text: "You find the nearest cave but it’s getting dark and you don’t want to risk finding Big Foot again.", optionOne: "Make a fire.", optionTwo: "Explore the big cave.", idOne: 16, idTwo: 17, image:#imageLiteral(resourceName: "pasted image 0-2")),
        Scenerio(id: 16, text: "You make a fire and stay until the next morning. You go home. Life Grade: A", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "FireInCave")),
        Scenerio(id: 17, text: "Explore the cave: You fall in the ravine and are trapped for days and suffer from hunger. You are faced with a tough choice: eat the local bats or starve.", optionOne: "Eat the bats", optionTwo: "Starve", idOne: 18, idTwo: 19, image:#imageLiteral(resourceName: "pasted image 0-2")),
        Scenerio(id: 18, text: "You eat a bat. Luckily the local park ranger finds you before you eat any more. However, you get the coronavirus and the caused a worldwide pandemic. Life Grade: F", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "1800x1200_virus_3d_render_red_03_other")),
        Scenerio(id: 19, text: "You refuse to eat a bat. Luckily the local park ranger finds you before you starve. You return home and live happily. Life Grade: A", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "pasted image 0-5")),
        Scenerio(id: 15, text: "You shoot and hit your target. But it was actually the local park ranger in a costume. He is severely injured.", optionOne: "Run for help", optionTwo: "Run away", idOne: 20, idTwo: 21, image:#imageLiteral(resourceName: "jpeg;base644918bfbf7a5f6f1b")),
        Scenerio(id: 20, text: "You run for help and find a nearby cabin with a paramedic. You save the person, but the person sues you in court the next week.", optionOne: "Get a lawyer with the money you have.", optionTwo: "Save your money.", idOne: 22, idTwo: 23, image:#imageLiteral(resourceName: "Courthouse")),
        Scenerio(id: 22, text: "The lawyer is bad and you lose the case and get incarcerated for 1 year. Life Grade: C", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "vault-bank-800x608")),
        Scenerio(id: 23, text: "You use the money you saved to bribe the judge and get no sentence. You do feel guilty though. Life Grade: B", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "Courthouse")),
        Scenerio(id: 21, text: "You escape the campsite with your stuff but you contemplate the next move.", optionOne: "Live a life of crime.", optionTwo: "Turn yourself in.", idOne: 24, idTwo: 25, image:#imageLiteral(resourceName: "pasted image 0-5")),
        Scenerio(id: 24, text: "For your first heist, you decide to rob a Subway but got caught and serve a lifetime in jail. Life Grade: F", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "vault-bank-800x608")),
        Scenerio(id: 25, text: "You turn yourself in but find out that the person miraculously survived and you only get a year in jail time. Life Grade: C", optionOne: "Restart", optionTwo: "Restart", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "vault-bank-800x608"))]
        
    var scenerioNumber:Int = 1
    lazy var currentScenerio = getScenerio(id: scenerioNumber)
    
    @IBAction func optionOne(_ sender: UIButton) {
        scenerioNumber = currentScenerio.idOne
        updateUI()
    }
    
    @IBAction func optionTwo(_ sender: UIButton) {
        scenerioNumber = currentScenerio.idTwo
        updateUI()
    }
    
    func getScenerio(id: Int) -> Scenerio{
        for item in pathways{
            if item.id == id{
                return item
            }
        }
        return Scenerio(id: 0, text: "Looks like there is a bug in the code!", optionOne: "Go back to beginning", optionTwo: "Go back to beginning", idOne: 1, idTwo: 1,image: #imageLiteral(resourceName: "jpeg;base64dc5c3398c1063bcc"))
    }
    
//    func goToQuestion(id: Int){
//
//    }
    
    
    @objc func updateUI(){
        currentScenerio = getScenerio(id: scenerioNumber)
        scenerioLabel.text = currentScenerio.text
        optionOne.setTitle(currentScenerio.optionOne, for: .normal)
        optionTwo.setTitle(currentScenerio.optionTwo, for: .normal)
        backgroundImage.image = currentScenerio.image
//        progressBar.setProgress(Float(questionNumber+1)/Float(quiz.count), animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }


}

