//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//  pingu

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scenerioLabel: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var optionOne: UIButton!
    @IBOutlet weak var optionTwo: UIButton!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    let pathways = [
        Scenerio(id: 1, text: "bruh moment", optionOne: "option1", optionTwo: "option2", idOne: 2, idTwo: 3, image: #imageLiteral(resourceName: "pasted image 0-5")),
        Scenerio(id: 2, text: "2", optionOne: "Back", optionTwo: "back", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "pasted image 0-3")),
        Scenerio(id: 3, text: "3", optionOne: "Back", optionTwo: "back", idOne: 1, idTwo: 1, image:#imageLiteral(resourceName: "NS_mixed_forest"))]
    
    var scenerioNumber:Int = 1
    lazy var currentScenerio = getScenerio(id: scenerioNumber)
    
    @IBAction func optionOne(_ sender: UIButton) {
        scenerioNumber = currentScenerio.idOne
        updateUI()
    }
    
    @IBAction func optionTwo(_ sender: UIButton) {
        scenerioNumber = currentScenerio.idTwo
        updateUI()
    }
    
    func getScenerio(id: Int) -> Scenerio{
        for item in pathways{
            if item.id == id{
                return item
            }
        }
        return Scenerio(id: 0, text: "Looks like there is a bug in the code!", optionOne: "Go back to beginning", optionTwo: "Go back to beginning", idOne: 1, idTwo: 1,image: #imageLiteral(resourceName: "jpeg;base64dc5c3398c1063bcc"))
    }
    
//    func goToQuestion(id: Int){
//
//    }
    
    
    @objc func updateUI(){
        currentScenerio = getScenerio(id: scenerioNumber)
        scenerioLabel.text = currentScenerio.text
        optionOne.setTitle(currentScenerio.optionOne, for: .normal)
        optionTwo.setTitle(currentScenerio.optionTwo, for: .normal)
        backgroundImage.image = currentScenerio.image
//        progressBar.setProgress(Float(questionNumber+1)/Float(quiz.count), animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }


}

