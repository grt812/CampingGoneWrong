//
//  Question.swift
//  Quizzler-iOS13
//
//  Created by Computer Science on 3/30/21.
//  Copyright © 2021 The App Brewery. All rights reserved.
//

import Foundation

struct Scenerio {
    let id: Int
    let text: String
    let optionOne: String
    let optionTwo: String
    let idOne: Int
    let idTwo: Int
    
    init(id: Int, text:String, optionOne:String, optionTwo: String, idOne: Int, idTwo: Int){
        self.id = id
        self.text = text
        self.optionOne = optionOne
        self.optionTwo = optionTwo
        self.idOne = idOne
        self.idTwo = idTwo
    }

    
}
