//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//  pingu

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scenerioLabel: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var optionOne: UIButton!
    @IBOutlet weak var optionTwo: UIButton!
    
    let pathways = [Scenerio(id: 1, text: "", optionOne: "Your mom", optionTwo: "Your mom2", idOne: 2, idTwo: 3)]
    
    var scenerioNumber:Int = 0
    lazy var currentScenerio = getScenerio(id: scenerioNumber)
    
    @IBAction func answerButton(_ sender: UIButton) {
        
    }
    
    func getScenerio(id: Int) -> Scenerio{
        for item in pathways{
            if item.id == id{
                return item
            }
        }
        var tempScenerio = Scenerio(id: 0. text: "", optionOne: "", optionTwo: "", idOne: 2, idTwo: 3)
        return tempScenerio
    }
    
    func goToQuestion(id: Int){
        
    }
    
    @objc func updateUI(){
        currentScenerio = getScenerio(id: scenerioNumber)
        scenerioLabel.text = currentScenerio.text
        optionOne.setTitle(currentScenerio.optionOne, for: .normal)
        optionTwo.setTitle(currentScenerio.optionTwo, for: .normal)
        
//        progressBar.setProgress(Float(questionNumber+1)/Float(quiz.count), animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }


}

